from django.shortcuts import get_object_or_404, render, redirect
from .forms import formProducto
from Clientes.models import  Boleta, Producto
from django.contrib.auth import authenticate, login,logout
from Clientes.forms import UserRegisterForm,DireccionEnvioForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Boleta, ProductoEnBoleta
from .forms import DireccionEnvioForm
from Clientes.models import Producto
from Clientes.serializers import ProductoS
from decimal import Decimal
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from django.urls import reverse
from rest_framework import permissions
from rest_framework.exceptions import PermissionDenied
from django.core.exceptions import PermissionDenied as DjangoPermissionDenied

class CustomPermissionDenied(PermissionDenied):
    default_detail = 'No tienes permiso para acceder a esta vista.'
    default_code = 'permission_denied'

class IsSuperUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_superuser

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoS
    
    def get_permissions(self):
        if self.action == 'create':
            permission_classes = [IsSuperUser]  # Permiso personalizado para la creación
        elif self.action in ['update', 'destroy', 'eliminar']:
            permission_classes = [IsSuperUser]  # Permiso personalizado para estas acciones
        else:
            permission_classes = [permissions.IsAuthenticated]  # Permiso predeterminado para las demás acciones
        return [permission() for permission in permission_classes]

    @action(detail=True, methods=['GET'])
    def check_permission(self, request, *args, **kwargs):
        try:
            self.custom_permission_check(request)
        except (PermissionDenied, DjangoPermissionDenied) as exc:
            return Response(str(exc), status=status.HTTP_403_FORBIDDEN)
        return Response("Permisos concedidos", status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)
    
    
    @action(detail=True, methods=['DELETE'])
    def eliminar(self, request, pk=None):
        producto = self.get_object()
        producto.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class vista1():
    def home(request):
        return render(request, 'home.html')

    def register(request):
        if request.method == 'POST':
            form = UserRegisterForm(request.POST)
            if form.is_valid():
                form.save()
                username = form.cleaned_data.get('username')
                messages.success(request, f'Usuario {username} creado con éxito.')
                return redirect('/registro')
        else:
            form = UserRegisterForm()
        return render(request, 'registro.html', {'form': form})

    def user_login(request):
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.error(request, 'Nombre de usuario o contraseña no válidos')
        return render(request, 'inicio_sesion.html')

    @login_required
    def user_logout(request):
        logout(request)
        return redirect('home')



    @login_required
    def add_to_cart(request, product_id):
        cart_key = f'cart_{request.user.id}'  # Clave única del carrito para cada usuario
        cart = request.session.get(cart_key, {})

        if str(product_id) in cart:
            cart[str(product_id)] += 1
        else:
            cart[str(product_id)] = 1

        request.session[cart_key] = cart
        return redirect('list_products')

    @login_required
    def view_cart(request):
        cart_key = f'cart_{request.user.id}'
        cart = request.session.get(cart_key, {})
        products_in_cart = {}
        
        for product_id, quantity in cart.items():
            product = get_object_or_404(Producto, id=product_id)
            products_in_cart[product] = quantity

        return render(request, 'carrito.html', {'cart': products_in_cart})

    @login_required
    def clear_cart(request):
        cart_key = f'cart_{request.user.id}'
        if cart_key in request.session:
            del request.session[cart_key]
        return redirect('view_cart')


    @login_required
    def checkout(request):
        cart_key = f'cart_{request.user.id}'
        cart = request.session.get(cart_key, {})
        
        if request.method == 'POST':
            form = DireccionEnvioForm(request.POST)
            if form.is_valid():
                nombre = form.cleaned_data['nombre']
                apellido = form.cleaned_data['apellido']
                direccion_envio = form.cleaned_data['direccion_envio']
                
                
                nueva_boleta = Boleta.objects.create(
                    user=request.user,
                    nombre=nombre,
                    apellido=apellido,
                    direccion_envio=direccion_envio,
                    
                )

                total = Decimal(0)
                productos_comprados = []

                for product_id, quantity in cart.items():
                    producto = get_object_or_404(Producto, id=product_id)
                    precio = producto.price
                    ProductoEnBoleta.objects.create(boleta=nueva_boleta, producto=producto, cantidad=quantity, precio=precio)

                    total += precio * quantity
                    productos_comprados.append(producto.name)

                total_con_iva = total * Decimal('1.15')

                request.session[cart_key] = {}

                return render(request, 'boleta.html', {
                    'nueva_boleta': nueva_boleta,
                    'productos_comprados': productos_comprados,
                    'total_con_iva': total_con_iva,
                })
        else:
            form = DireccionEnvioForm()

        return render(request, 'confirmacion.html', {'form': form})
              
    def list_products(request):
        products = Producto.objects.all()
        return render(request, 'index.html', {'products': products})
        
    from django.shortcuts import redirect

    def eliminarProyecto(request, id):
        proyecto = Producto.objects.get(id=id)
        proyecto.delete()
        return redirect(reverse('producto-list'))

    def actualizarProyecto(request, id):
        proyecto = Producto.objects.get(id=id)
        form = formProducto(instance=proyecto)
            
        if request.method == 'POST':
            form = formProducto(request.POST, instance=proyecto)
            if form.is_valid():
                form.save()
                return redirect(reverse('producto-list'))  # Redirige a la API de productos después de editar
        data = { 'form': form}
        return render(request, 'index.html', data)

    

            

