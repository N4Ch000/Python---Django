from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone
from django.contrib.auth.models import User
from django.forms import ValidationError

nombre_validator = RegexValidator(
    regex=r'^[a-zA-Z\s]+$',
    message='El nombre solo debe contener letras y espacios.',
    code='invalid_nombre'
)

apellido_validator = RegexValidator(
    regex=r'^[a-zA-Z\s]+$',
    message='El apellido solo debe contener letras y espacios.',
    code='invalid_apellido'
)
    
TIPO_CHOICES = [
    ('Vinilo', 'LP'),
    ('CD', 'CD'),
    ('Tape', 'Cassette')
]
class Producto(models.Model):
    name = models.CharField(max_length=100, verbose_name="Nombre")
    description = models.TextField(verbose_name="Descripción")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Precio")
    formato = models.CharField(
        max_length=12,
        choices=TIPO_CHOICES
    )
    imagen = models.ImageField(upload_to='images/', blank=True, null=True) 

    def __str__(self):
     return f"Nombre: {self.name}, Descripción: {self.description}, Precio: {self.price}, Formato: {self.get_formato_display()}, Imagen: {self.imagen.url if self.imagen else 'N/A'}"
    
    
class Boleta(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=100, validators=[nombre_validator])  # Campo para el nombre
    apellido = models.CharField(max_length=100,validators=[apellido_validator])  # Campo para el apellido
    direccion_envio = models.TextField(max_length=100,verbose_name="Dirección de envío")
    fecha_compra = models.DateTimeField(auto_now_add=True)
    

    def save(self, *args, **kwargs):
        if not self.pk:  # Verifica si el objeto es nuevo
            self.fecha_compra = timezone.now()  # Establece la fecha de compra en tiempo real

            # Si necesitas validar que la hora sea exactamente la hora actual, puedes hacerlo aquí
            if self.fecha_compra.time() != timezone.now().time():
                raise ValidationError('La hora de compra no es la hora actual.')

        super().save(*args, **kwargs)

    def __str__(self):
        return f'Boleta #{self.id} - {self.user.username}'


class ProductoEnBoleta(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    boleta = models.ForeignKey(Boleta, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    precio = models.DecimalField(max_digits=10, decimal_places=2)  # Precio en el momento de la compra

    def subtotal(self):
        return self.cantidad * self.precio
    
    
    
    


