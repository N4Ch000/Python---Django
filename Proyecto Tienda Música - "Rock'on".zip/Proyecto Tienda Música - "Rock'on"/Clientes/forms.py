from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from Clientes.models import Producto

class formProducto(forms.ModelForm):
    class Meta:
        model = Producto
        fields = '__all__'
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['imagen'].widget.attrs.update({'accept': '.jpg, .jpeg, .png, .gif'})


class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(label='Correo Electrónico')
    apellido = forms.CharField(max_length=30, label='Apellido')
    rut = forms.CharField(max_length=12, label='RUT')

    class Meta:
        model = User
        fields = ['username', 'email', 'apellido', 'rut', 'password1', 'password2']
        labels = {
            'username': 'Nombre de Usuario',
        }

class DireccionEnvioForm(forms.Form):
    nombre = forms.CharField(label='Nombre', max_length=100)
    apellido = forms.CharField(label='Apellido', max_length=100)
    direccion_envio = forms.CharField(label='Dirección de envío', max_length=200)
    
        
    