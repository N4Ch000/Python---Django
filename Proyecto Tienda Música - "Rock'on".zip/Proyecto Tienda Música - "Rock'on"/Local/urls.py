"""
URL configuration for Tienda project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib.auth.decorators import user_passes_test
from django.contrib import admin
from django.urls import path, include
from Clientes.views import vista1, ProductoViewSet
from Rockon.views import home, register, employee_login, employee_logout, admin_api, CombinedAPIView, FuncionarioViewSet
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter

router_funcionario = DefaultRouter()
router_funcionario.register(r'funcionario', FuncionarioViewSet, basename='funcionario')
router_producto = DefaultRouter()
router_producto.register(r'producto', ProductoViewSet, basename='producto')

def es_admin(user):
    return user.is_superuser if user else False

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('registropersonal/', register),
    path('login/', employee_login),
    path('salir/', employee_logout),
    path('accounts/', include('django.contrib.auth.urls')),
    path('registro/', vista1.register, name='register'),
    path('login/', vista1.user_login, name='login'),
    path('logout/', vista1.user_logout, name='user_logout'),
    path('productos/', vista1.list_products, name='list_products'),
    path('add_to_cart/<int:product_id>/', vista1.add_to_cart, name='add_to_cart'),
    path('view_cart/', vista1.view_cart, name='view_cart'),
    path('clear_cart/', vista1.clear_cart, name='clear_cart'),
    path('boleta/', vista1.checkout, name='boleta'),
    path('eliminarProyecto/<int:id>/', vista1.eliminarProyecto),
    path('actualizarProyecto/<int:id>/', vista1.actualizarProyecto),
    path('api/combined/', CombinedAPIView.as_view(), name='combined_api'),
    path('api/funcionario/', include(router_funcionario.urls)),
    path('api/clientes/', include(router_producto.urls)),
    path('api/clientes/agregar/', ProductoViewSet.as_view({'post': 'create'}), name='agregar_producto'),
    path('api/clientes/<int:pk>/editar/', ProductoViewSet.as_view({'put': 'update'}), name='editar_producto'),
    path('api/clientes/<int:pk>/eliminar/', ProductoViewSet.as_view({'delete': 'eliminar'}), name='eliminar_producto'),
    path('admin_api/', user_passes_test(es_admin)(admin_api), name='admin_api'),
    
]  + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)





