from django.db import models
from django.core.validators import RegexValidator
from django.forms import ValidationError
# Create your models here.

nombre_validator = RegexValidator(
    regex=r'^[a-zA-Z\s]+$',
    message='El nombre solo debe contener letras y espacios.',
    code='invalid_nombre'
)

apellido_validator = RegexValidator(
    regex=r'^[a-zA-Z\s]+$',
    message='El apellido solo debe contener letras y espacios.',
    code='invalid_apellido'
)
class Funcionario(models.Model):
    JORNADAS =[('Parcial','PARCIAL'),('Completa','COMPLETA')]
    CONTRATO =[('Honorario', 'HONORARIO'),('Contrata','CONTRATA')]
    nombre = models.CharField(max_length=50, validators=[nombre_validator])
    apellido = models.CharField(max_length=50, validators=[apellido_validator])
    rut = models.CharField(
        max_length=12,
        default='00000000-0',
        validators=[
            RegexValidator(
                regex=r'^\d{1,2}\.\d{3}\.\d{3}-[0-9kK]{1}$',
                message='El RUT debe tener el formato XX.XXX.XXX-X',
                code='invalid_rut'
            )
        ]
    )
    email = models.EmailField()
    direccion = models.CharField(max_length=10)
    fechaInicio = models.DateField(max_length=10)
    fechaTermino = models.DateField(max_length=10)
    jornada = models.CharField(max_length=20,choices=JORNADAS)
    tipoContrato = models.CharField(max_length=20,choices=CONTRATO)
    cargo = models.TextField(max_length=20)
    sueldoBruto = models.FloatField(max_length=10)

    def __str__(self):
     return f"Nombre: {self.nombre}, Apellido: {self.apellido}, Rut: {self.rut}, Email: {self.email}, Dirección: {self.direccion}, Fecha de Inicio: {self.fechaInicio}, Fecha de Término: {self.fechaTermino}, Jornada: {self.jornada}, Tipo de Contrato: {self.tipoContrato}, Cargo: {self.cargo}, Sueldo Bruto: {self.sueldoBruto}"
    def clean(self):
        if self.fechaInicio > self.fechaTermino:
            raise ValidationError(('La fecha de inicio no puede ser después de la fecha de término.'))

    def save(self, *args, **kwargs):
        if self.sueldoBruto < 0:
            raise ValidationError(('El sueldo bruto no puede ser negativo.'))
        super().save(*args, **kwargs)
    
    
    


   
