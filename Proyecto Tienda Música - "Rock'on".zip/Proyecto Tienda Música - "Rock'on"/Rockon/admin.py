from django.contrib import admin
from .models import Funcionario

# Register your models here.
class LocalAdmin(admin.ModelAdmin):
    list_display = ['nombre','email','fechaInicio','fechaTermino','jornada','tipoContrato','cargo','sueldoBruto']
    

admin.site.register(Funcionario,LocalAdmin)




