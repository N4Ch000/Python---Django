from django import forms
from Rockon.models import Funcionario
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class FormTienda(forms.ModelForm):
    class Meta:
        model = Funcionario
        fields = '__all__'

class EmployeeRegisterForm(UserCreationForm):
    email = forms.EmailField(label='Correo Electrónico')
    apellido = forms.CharField(max_length=30, label='Apellido')
    rut = forms.CharField(max_length=12, label='RUT')

    class Meta:
        model = User
        fields = ['username', 'email', 'apellido', 'rut', 'password1', 'password2']
        labels = {
            'username': 'Nombre de Usuario',
        }

   