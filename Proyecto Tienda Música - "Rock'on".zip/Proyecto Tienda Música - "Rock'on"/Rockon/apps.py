from django.apps import AppConfig


class RockonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Rockon'
