from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages
from Rockon.forms import EmployeeRegisterForm
from Rockon.models import Funcionario
from Rockon.serializers import FuncionarioS
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import viewsets
from rest_framework import status
from django.contrib.auth.models import User
from django.contrib.admin.views.decorators import staff_member_required
from django.http import JsonResponse


# Create your views here.
def home(request):
    return render(request, 'home.html')

def register(request):
    if request.method == "POST":
        form = EmployeeRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request,f'Usuario{username} creado exitosamente')
            return redirect('/')
    else:
        form = EmployeeRegisterForm()
    return render(request,'registropersonal.html', {'form':form})

def employee_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/')
        else:
            messages.error(request,'Nombre de usuario o contraseña no válido')
    return render(request, 'login.html')

@login_required
def employee_logout(request):
    logout(request)
    return redirect('/')

from django.contrib.admin.views.decorators import staff_member_required
from django.http import HttpResponse

@staff_member_required
def admin_api(request):
    if request.method == 'GET':
        if request.user.is_superuser:  # Verificar si el usuario es un administrador
            users = User.objects.all()
            user_list = [{'username': user.username, 'email': user.email} for user in users]
            return JsonResponse({'users': user_list})
        else:
            return JsonResponse({'error': 'No tienes permiso para acceder a esta vista'})
    else:
        return JsonResponse({'error': 'Método no permitido'})



from rest_framework.response import Response
from rest_framework.views import APIView
from Rockon.models import Funcionario
from Clientes.models import Producto
from Rockon.serializers import FuncionarioS
from Clientes.serializers import ProductoS

from rest_framework import permissions
from rest_framework.permissions import IsAuthenticated, IsAdminUser

class IsSuperUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_superuser

class CombinedAPIView(APIView):
    permission_classes = [IsAdminUser] 
    permission_classes = [permissions.IsAuthenticated, IsSuperUser]
    def get(self, request):
        funcionarios = Funcionario.objects.all()
        productos = Producto.objects.all()

        funcionarios_serialized = FuncionarioS(funcionarios, many=True).data
        productos_serialized = ProductoS(productos, many=True).data

        combined_data = {
            'funcionarios': funcionarios_serialized,
            'productos': productos_serialized,
        }

        return Response(combined_data)
    
from rest_framework import viewsets
from rest_framework.response import Response
from .models import Funcionario
from .serializers import FuncionarioS
from rest_framework import status
from rest_framework.decorators import action
from django.core.exceptions import PermissionDenied as DjangoPermissionDenied
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import BasePermission

class CustomPermissionDenied(PermissionDenied):
    default_detail = 'No tienes permiso para acceder a esta vista.'
    default_code = 'permission_denied'

class IsSuperUser(BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_superuser

class FuncionarioViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAdminUser] 
    permission_classes = [permissions.IsAuthenticated, IsSuperUser]
    queryset = Funcionario.objects.all()
    serializer_class = FuncionarioS

    def custom_permission_check(self, request):
        raise CustomPermissionDenied()

    @action(detail=True, methods=['GET'])
    def check_permission(self, request, *args, **kwargs):
        try:
            self.custom_permission_check(request)
        except (PermissionDenied, DjangoPermissionDenied) as exc:
            return Response(str(exc), status=status.HTTP_403_FORBIDDEN)
        return Response("Permisos concedidos", status=status.HTTP_200_OK)

    def create(self, request, *args, **kwargs):
        try:
            self.custom_permission_check(request)
        except (PermissionDenied, DjangoPermissionDenied) as exc:
            return Response(str(exc), status=status.HTTP_403_FORBIDDEN)
        
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def update(self, request, *args, **kwargs):
        try:
            self.custom_permission_check(request)
        except (PermissionDenied, DjangoPermissionDenied) as exc:
            return Response(str(exc), status=status.HTTP_403_FORBIDDEN)
        
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def destroy(self, request, *args, **kwargs):
        try:
            self.custom_permission_check(request)
        except (PermissionDenied, DjangoPermissionDenied) as exc:
            return Response(str(exc), status=status.HTTP_403_FORBIDDEN)
        
        instance = self.get_object()
        self.perform_destroy(instance)
        return Response(status=status.HTTP_204_NO_CONTENT)




